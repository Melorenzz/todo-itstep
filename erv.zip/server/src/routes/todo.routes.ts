import { Router } from 'express';
import { TodoController } from '../controllers/todo.controller';
import {
  validateCreateTodo,
  validateUpdateTodo,
  validateTodoId,
  validateStatusUpdate
} from '../middleware/validation.middleware';

export class TodoRoutes {
  public router: Router;
  private todoController: TodoController;

  constructor() {
    this.router = Router();
    this.todoController = new TodoController();
    this.initializeRoutes();
  }

  private initializeRoutes(): void {
    // Create todo
    this.router.post('/', validateCreateTodo, this.todoController.createTodo);

    // Get all todos (with optional status filter)
    this.router.get('/', this.todoController.getAllTodos);

    // Get todo by ID
    this.router.get('/:id', validateTodoId, this.todoController.getTodoById);

    // Update todo
    this.router.put('/:id', validateTodoId, validateUpdateTodo, this.todoController.updateTodo);

    // Delete todo
    this.router.delete('/:id', validateTodoId, this.todoController.deleteTodo);

    // Update todo status
    this.router.patch('/:id/status', validateTodoId, validateStatusUpdate, this.todoController.updateTodoStatus);
  }
}
