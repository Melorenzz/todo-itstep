import express, { Application } from 'express';
import cors from 'cors';
import { TodoRoutes } from './routes/todo.routes';
import { errorHandler, notFoundHandler } from './middleware/error.middleware';
import { ApiResponse } from './types/todo.types';
import { testConnection } from './database/connection';

export class App {
  public app: Application;
  private todoRoutes: TodoRoutes;

  constructor() {
    this.app = express();
    this.todoRoutes = new TodoRoutes();
    this.initializeMiddlewares();
    this.initializeRoutes();
    this.initializeErrorHandlers();
  }

  private initializeMiddlewares(): void {
    // CORS configuration
    this.app.use(cors({
      origin: ['http://localhost:3000', 'http://localhost:5000', '*', 'http://localhost:5173'],
      methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
      allowedHeaders: ['Content-Type', 'Authorization'],
      credentials: true
    }));

    // Body parser middleware
    this.app.use(express.json({ limit: '10mb' }));
    this.app.use(express.urlencoded({ extended: true, limit: '10mb' }));

    // Request logging middleware
    this.app.use((req, res, next) => {
      console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
      next();
    });
  }

  private initializeRoutes(): void {
    // Health check endpoint
    this.app.get('/health', (req, res) => {
      const response: ApiResponse = {
        success: true,
        message: 'Todo API server is running',
        data: {
          timestamp: new Date().toISOString(),
          version: '1.0.0',
          status: 'healthy'
        }
      };
      res.status(200).json(response);
    });

    // API routes
    this.app.use('/api/todos', this.todoRoutes.router);

    // API documentation endpoint
    this.app.get('/api', (req, res) => {
      const response: ApiResponse = {
        success: true,
        message: 'Todo API Documentation',
        data: {
          endpoints: {
            'GET /api/todos': 'Get all todos (optional ?status=pending|in-progress|completed)',
            'POST /api/todos': 'Create a new todo',
            'GET /api/todos/:id': 'Get todo by ID',
            'PUT /api/todos/:id': 'Update todo',
            'DELETE /api/todos/:id': 'Delete todo',
            'PATCH /api/todos/:id/status': 'Update todo status'
          },
          todoStatuses: ['pending', 'in-progress', 'completed']
        }
      };
      res.status(200).json(response);
    });
  }

  private initializeErrorHandlers(): void {
    // 404 handler
    this.app.use(notFoundHandler);

    // Global error handler
    this.app.use(errorHandler);
  }

  public async listen(port: number): Promise<void> {
    // Test database connection before starting server
    const dbConnected = await testConnection();
    if (!dbConnected) {
      console.error('❌ Failed to connect to database. Server not started.');
      process.exit(1);
    }

    this.app.listen(port, '0.0.0.0', () => {
      console.log(`🚀 Todo API server is running on http://0.0.0.0:${port}`);
      console.log(`📚 API Documentation: http://0.0.0.0:${port}/api`);
      console.log(`🏥 Health Check: http://0.0.0.0:${port}/health`);
    });
  }
}
