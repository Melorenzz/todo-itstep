import { CreateTodoDto, UpdateTodoDto, TodoStatus } from '../types/todo.types';
import { Todo } from '../database/schema';
import { db } from '../database/connection';
import { todos } from '../database/schema';
import { eq } from 'drizzle-orm';
import { v4 as uuidv4 } from 'uuid';
import { MemoryTodoService } from './memory-todo.service';

// Create memory service instance for fallback
const memoryService = new MemoryTodoService();

export class TodoService {
  
  private isMemoryMode(): boolean {
    return !process.env.DATABASE_URL;
  }

  /**
   * Create a new todo
   */
  async createTodo(createTodoDto: CreateTodoDto): Promise<Todo> {
    if (this.isMemoryMode()) {
      return await memoryService.createTodo(createTodoDto);
    }
    
    const newTodo = {
      id: uuidv4(),
      title: createTodoDto.title,
      description: createTodoDto.description,
      status: TodoStatus.PENDING as const,
    };

    await db.insert(todos).values(newTodo);
    
    // Отримуємо створений todo з бази
    const [createdTodo] = await db.select().from(todos).where(eq(todos.id, newTodo.id));
    return createdTodo;
  }

  /**
   * Get all todos
   */
  async getAllTodos(): Promise<Todo[]> {
    if (this.isMemoryMode()) {
      return await memoryService.getAllTodos();
    }
    
    const result = await db.select().from(todos);
    return result;
  }

  /**
   * Get todo by ID
   */
  async getTodoById(id: string): Promise<Todo | null> {
    if (this.isMemoryMode()) {
      return await memoryService.getTodoById(id);
    }
    
    const [result] = await db.select().from(todos).where(eq(todos.id, id));
    return result || null;
  }

  /**
   * Update todo by ID
   */
  async updateTodo(id: string, updateTodoDto: UpdateTodoDto): Promise<Todo | null> {
    if (this.isMemoryMode()) {
      return await memoryService.updateTodo(id, updateTodoDto);
    }
    
    // Перевіряємо чи існує todo
    const existingTodo = await this.getTodoById(id);
    if (!existingTodo) {
      return null;
    }

    // Оновлюємо todo
    await db.update(todos)
      .set(updateTodoDto)
      .where(eq(todos.id, id));

    // Повертаємо оновлений todo
    const [updatedTodo] = await db.select().from(todos).where(eq(todos.id, id));
    return updatedTodo;
  }

  /**
   * Delete todo by ID
   */
  async deleteTodo(id: string): Promise<boolean> {
    if (this.isMemoryMode()) {
      return await memoryService.deleteTodo(id);
    }
    
    // Перевіряємо чи існує todo перед видаленням
    const existingTodo = await this.getTodoById(id);
    if (!existingTodo) {
      return false;
    }

    await db.delete(todos).where(eq(todos.id, id));
    return true;
  }

  /**
   * Update todo status
   */
  async updateTodoStatus(id: string, status: TodoStatus): Promise<Todo | null> {
    if (this.isMemoryMode()) {
      return await memoryService.updateTodoStatus(id, status);
    }
    
    // Перевіряємо чи існує todo
    const existingTodo = await this.getTodoById(id);
    if (!existingTodo) {
      return null;
    }

    // Оновлюємо статус
    await db.update(todos)
      .set({ status })
      .where(eq(todos.id, id));

    // Повертаємо оновлений todo
    const [updatedTodo] = await db.select().from(todos).where(eq(todos.id, id));
    return updatedTodo;
  }

  /**
   * Get todos by status
   */
  async getTodosByStatus(status: TodoStatus): Promise<Todo[]> {
    if (this.isMemoryMode()) {
      return await memoryService.getTodosByStatus(status);
    }
    
    const result = await db.select().from(todos).where(eq(todos.status, status));
    return result;
  }
}
