import { CreateTodoDto, UpdateTodoDto, TodoStatus } from '../types/todo.types';
import { Todo } from '../database/schema';
import { v4 as uuidv4 } from 'uuid';

// In-memory storage
const todoStorage = new Map<string, Todo>();

export class MemoryTodoService {
  /**
   * Create a new todo
   */
  async createTodo(createTodoDto: CreateTodoDto): Promise<Todo> {
    const newTodo: Todo = {
      id: uuidv4(),
      title: createTodoDto.title,
      description: createTodoDto.description,
      status: TodoStatus.PENDING as const,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    todoStorage.set(newTodo.id, newTodo);
    return newTodo;
  }

  /**
   * Get all todos
   */
  async getAllTodos(): Promise<Todo[]> {
    return Array.from(todoStorage.values());
  }

  /**
   * Get todo by ID
   */
  async getTodoById(id: string): Promise<Todo | null> {
    return todoStorage.get(id) || null;
  }

  /**
   * Update todo by ID
   */
  async updateTodo(id: string, updateTodoDto: UpdateTodoDto): Promise<Todo | null> {
    const existingTodo = todoStorage.get(id);
    if (!existingTodo) {
      return null;
    }

    const updatedTodo: Todo = {
      ...existingTodo,
      ...updateTodoDto,
      updatedAt: new Date(),
    };

    todoStorage.set(id, updatedTodo);
    return updatedTodo;
  }

  /**
   * Delete todo by ID
   */
  async deleteTodo(id: string): Promise<boolean> {
    return todoStorage.delete(id);
  }

  /**
   * Update todo status
   */
  async updateTodoStatus(id: string, status: TodoStatus): Promise<Todo | null> {
    const existingTodo = todoStorage.get(id);
    if (!existingTodo) {
      return null;
    }

    const updatedTodo: Todo = {
      ...existingTodo,
      status,
      updatedAt: new Date(),
    };

    todoStorage.set(id, updatedTodo);
    return updatedTodo;
  }

  /**
   * Get todos by status
   */
  async getTodosByStatus(status: TodoStatus): Promise<Todo[]> {
    return Array.from(todoStorage.values()).filter(todo => todo.status === status);
  }
}