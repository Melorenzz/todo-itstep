import { Request, Response } from 'express';
import { TodoService } from '../services/todo.service';
import { CreateTodoDto, UpdateTodoDto, TodoStatus, ApiResponse } from '../types/todo.types';

export class TodoController {
  private todoService: TodoService;

  constructor() {
    this.todoService = new TodoService();
  }

  /**
   * Create a new todo
   */
  createTodo = async (req: Request, res: Response): Promise<void> => {
    try {
      const createTodoDto: CreateTodoDto = req.body;
      const todo = await this.todoService.createTodo(createTodoDto);

      const response: ApiResponse = {
        success: true,
        message: 'Todo created successfully',
        data: todo
      };

      res.status(201).json(response);
    } catch (error) {
      const response: ApiResponse = {
        success: false,
        message: 'Failed to create todo',
        error: error instanceof Error ? error.message : 'Unknown error'
      };

      res.status(500).json(response);
    }
  };

  /**
   * Get all todos
   */
  getAllTodos = async (req: Request, res: Response): Promise<void> => {
    try {
      const { status } = req.query;
      let todos;

      if (status && Object.values(TodoStatus).includes(status as TodoStatus)) {
        todos = await this.todoService.getTodosByStatus(status as TodoStatus);
      } else {
        todos = await this.todoService.getAllTodos();
      }

      const response: ApiResponse = {
        success: true,
        message: 'Todos retrieved successfully',
        data: todos
      };

      res.status(200).json(response);
    } catch (error) {
      const response: ApiResponse = {
        success: false,
        message: 'Failed to retrieve todos',
        error: error instanceof Error ? error.message : 'Unknown error'
      };

      res.status(500).json(response);
    }
  };

  /**
   * Get todo by ID
   */
  getTodoById = async (req: Request, res: Response): Promise<void> => {
    try {
      const { id } = req.params;
      const todo = await this.todoService.getTodoById(id);

      if (!todo) {
        const response: ApiResponse = {
          success: false,
          message: 'Todo not found'
        };

        res.status(404).json(response);
        return;
      }

      const response: ApiResponse = {
        success: true,
        message: 'Todo retrieved successfully',
        data: todo
      };

      res.status(200).json(response);
    } catch (error) {
      const response: ApiResponse = {
        success: false,
        message: 'Failed to retrieve todo',
        error: error instanceof Error ? error.message : 'Unknown error'
      };

      res.status(500).json(response);
    }
  };

  /**
   * Update todo
   */
  updateTodo = async (req: Request, res: Response): Promise<void> => {
    try {
      const { id } = req.params;
      const updateTodoDto: UpdateTodoDto = req.body;
      
      const todo = await this.todoService.updateTodo(id, updateTodoDto);

      if (!todo) {
        const response: ApiResponse = {
          success: false,
          message: 'Todo not found'
        };

        res.status(404).json(response);
        return;
      }

      const response: ApiResponse = {
        success: true,
        message: 'Todo updated successfully',
        data: todo
      };

      res.status(200).json(response);
    } catch (error) {
      const response: ApiResponse = {
        success: false,
        message: 'Failed to update todo',
        error: error instanceof Error ? error.message : 'Unknown error'
      };

      res.status(500).json(response);
    }
  };

  /**
   * Delete todo
   */
  deleteTodo = async (req: Request, res: Response): Promise<void> => {
    try {
      const { id } = req.params;
      const deleted = await this.todoService.deleteTodo(id);

      if (!deleted) {
        const response: ApiResponse = {
          success: false,
          message: 'Todo not found'
        };

        res.status(404).json(response);
        return;
      }

      const response: ApiResponse = {
        success: true,
        message: 'Todo deleted successfully'
      };

      res.status(200).json(response);
    } catch (error) {
      const response: ApiResponse = {
        success: false,
        message: 'Failed to delete todo',
        error: error instanceof Error ? error.message : 'Unknown error'
      };

      res.status(500).json(response);
    }
  };

  /**
   * Update todo status
   */
  updateTodoStatus = async (req: Request, res: Response): Promise<void> => {
    try {
      const { id } = req.params;
      const { status } = req.body;

      if (!Object.values(TodoStatus).includes(status)) {
        const response: ApiResponse = {
          success: false,
          message: 'Invalid status. Valid statuses are: pending, in-progress, completed'
        };

        res.status(400).json(response);
        return;
      }

      const todo = await this.todoService.updateTodoStatus(id, status);

      if (!todo) {
        const response: ApiResponse = {
          success: false,
          message: 'Todo not found'
        };

        res.status(404).json(response);
        return;
      }

      const response: ApiResponse = {
        success: true,
        message: 'Todo status updated successfully',
        data: todo
      };

      res.status(200).json(response);
    } catch (error) {
      const response: ApiResponse = {
        success: false,
        message: 'Failed to update todo status',
        error: error instanceof Error ? error.message : 'Unknown error'
      };

      res.status(500).json(response);
    }
  };
}
