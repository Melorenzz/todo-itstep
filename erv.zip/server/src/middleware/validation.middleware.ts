import { Request, Response, NextFunction } from 'express';
import { CreateTodoDto, UpdateTodoDto, TodoStatus, ApiResponse } from '../types/todo.types';

/**
 * Validate create todo request
 */
export const validateCreateTodo = (req: Request, res: Response, next: NextFunction): void => {
  const { title, description } = req.body as CreateTodoDto;

  const errors: string[] = [];

  if (!title || typeof title !== 'string' || title.trim().length === 0) {
    errors.push('Title is required and must be a non-empty string');
  }

  if (!description || typeof description !== 'string' || description.trim().length === 0) {
    errors.push('Description is required and must be a non-empty string');
  }

  if (title && title.length > 100) {
    errors.push('Title must be less than 100 characters');
  }

  if (description && description.length > 500) {
    errors.push('Description must be less than 500 characters');
  }

  if (errors.length > 0) {
    const response: ApiResponse = {
      success: false,
      message: 'Validation failed',
      error: errors.join(', ')
    };

    res.status(400).json(response);
    return;
  }

  // Trim whitespace
  req.body.title = title.trim();
  req.body.description = description.trim();

  next();
};

/**
 * Validate update todo request
 */
export const validateUpdateTodo = (req: Request, res: Response, next: NextFunction): void => {
  const { title, description, status } = req.body as UpdateTodoDto;

  const errors: string[] = [];

  if (title !== undefined) {
    if (typeof title !== 'string' || title.trim().length === 0) {
      errors.push('Title must be a non-empty string');
    }
    if (title.length > 100) {
      errors.push('Title must be less than 100 characters');
    }
  }

  if (description !== undefined) {
    if (typeof description !== 'string' || description.trim().length === 0) {
      errors.push('Description must be a non-empty string');
    }
    if (description.length > 500) {
      errors.push('Description must be less than 500 characters');
    }
  }

  if (status !== undefined) {
    if (!Object.values(TodoStatus).includes(status)) {
      errors.push('Status must be one of: pending, in-progress, completed');
    }
  }

  // Check if at least one field is provided
  if (title === undefined && description === undefined && status === undefined) {
    errors.push('At least one field (title, description, or status) must be provided');
  }

  if (errors.length > 0) {
    const response: ApiResponse = {
      success: false,
      message: 'Validation failed',
      error: errors.join(', ')
    };

    res.status(400).json(response);
    return;
  }

  // Trim whitespace
  if (title) req.body.title = title.trim();
  if (description) req.body.description = description.trim();

  next();
};

/**
 * Validate todo ID parameter
 */
export const validateTodoId = (req: Request, res: Response, next: NextFunction): void => {
  const { id } = req.params;

  if (!id || typeof id !== 'string' || id.trim().length === 0) {
    const response: ApiResponse = {
      success: false,
      message: 'Invalid todo ID'
    };

    res.status(400).json(response);
    return;
  }

  next();
};

/**
 * Validate status update request
 */
export const validateStatusUpdate = (req: Request, res: Response, next: NextFunction): void => {
  const { status } = req.body;

  if (!status || typeof status !== 'string') {
    const response: ApiResponse = {
      success: false,
      message: 'Status is required and must be a string'
    };

    res.status(400).json(response);
    return;
  }

  if (!Object.values(TodoStatus).includes(status as TodoStatus)) {
    const response: ApiResponse = {
      success: false,
      message: 'Invalid status. Valid statuses are: pending, in-progress, completed'
    };

    res.status(400).json(response);
    return;
  }

  next();
};
