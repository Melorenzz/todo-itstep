import { db } from './connection';
import { todos } from './schema';

async function migrate() {
  try {
    console.log('🔄 Running database migration...');
    
    // Create enum type if not exists
    await db.execute(`
      CREATE TYPE IF NOT EXISTS status AS ENUM ('pending', 'in-progress', 'completed')
    `);
    
    // Create table if not exists
    await db.execute(`
      CREATE TABLE IF NOT EXISTS todos (
        id VARCHAR(36) PRIMARY KEY,
        title VARCHAR(100) NOT NULL,
        description TEXT NOT NULL,
        status status NOT NULL DEFAULT 'pending',
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
      )
    `);
    
    // Create trigger for updated_at
    await db.execute(`
      CREATE OR REPLACE FUNCTION update_updated_at_column()
      RETURNS TRIGGER AS $$
      BEGIN
          NEW.updated_at = CURRENT_TIMESTAMP;
          RETURN NEW;
      END;
      $$ language 'plpgsql'
    `);
    
    await db.execute(`
      DROP TRIGGER IF EXISTS update_todos_updated_at ON todos
    `);
    
    await db.execute(`
      CREATE TRIGGER update_todos_updated_at 
        BEFORE UPDATE ON todos 
        FOR EACH ROW 
        EXECUTE FUNCTION update_updated_at_column()
    `);
    
    console.log('✅ Database migration completed successfully');
  } catch (error) {
    console.error('❌ Database migration failed:', error);
    throw error;
  }
}

// Run migration if called directly
if (require.main === module) {
  migrate()
    .then(() => process.exit(0))
    .catch(() => process.exit(1));
}

export { migrate };