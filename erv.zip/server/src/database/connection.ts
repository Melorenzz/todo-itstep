import { drizzle } from 'drizzle-orm/node-postgres';
import { Pool } from 'pg';
import * as schema from './schema';

// Initialize database connection if DATABASE_URL is available
let poolConnection: Pool | null = null;
let db: any = null;

if (process.env.DATABASE_URL) {
  poolConnection = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: false
  });
  db = drizzle(poolConnection, { schema });
}

export { db };

// Test database connection
export async function testConnection() {
  if (!process.env.DATABASE_URL) {
    console.log('📝 Using in-memory storage (no DATABASE_URL found)');
    return true;
  }
  
  try {
    const client = await poolConnection!.connect();
    await client.query('SELECT 1');
    client.release();
    console.log('✅ Database connected successfully');
    return true;
  } catch (error) {
    console.error('❌ Database connection failed:', error);
    return false;
  }
}